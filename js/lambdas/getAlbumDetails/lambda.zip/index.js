'use strict';

// var cheerio = require('cheerio')
// var request = require('request')

var dynamo = require('dynamo')
var metaspot = require('metaspot')

exports.handler = (event, context, callback) => {
  var state = {
    query: null,
    data: null,
    releaseDate: null,
    year: event.year,
    index: event.index,
    dateKeyIndex: event.dateKeyIndex
  };
  
  function *main() {
    state.query = M.getQuery('Metaspot', { 
      year: state.year
    })
    
    state.data = yield D.get(state.query)
    
    state.releaseDate = M.parseResponse('Metaspot', state.data, {
      year: state.year,
      dateKeyIndex: state.dateKeyIndex
    })
    
    state.query = M.getQuery('FetchedAlbums', { 
      releaseDate: state.releaseDate
    })
    
    state.data = yield D.query(state.query)
    
    console.log(state.data)
  }
  
  var it = main()
  var D = new dynamo(context, it)
  var M = new metaspot(context)
  
  it.next()
}
