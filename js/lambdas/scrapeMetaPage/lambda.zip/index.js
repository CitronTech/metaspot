'use strict'

var dynamo = require('dynamo')
var metaspot = require('metaspot')
var crawler = require('crawler')
var utils = require('utils')

exports.handler = (event, context, callback) => {
  var result = {
    albums: []
  }
  
  function *main() {
    if (typeof event.page === 'number') {
      U.next(yield C.open('http://www.metacritic.com/browse/albums/release-date/available/date?page=' + event.page))
      U.next(M.parseHtml('getAlbums', U.value))
      result = U.value
    } else {
      result = {
        success: false,
        error: 'Invalid handler parameters'
      }
    }
    
    callback(null, result)
  }
  
  var it = main()
  var U = new utils(context, callback)
  var M = new metaspot(U)
  var D = new dynamo(it, U)
  var C = new crawler(it, U) 

  it.next()
};
